#include "common.h"

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

void err_usr(const char *str)
{
	fputs(str, stderr);
	exit(2);
}

void usage()
{
	printf("Usage: ./appname -index|-test1|test2 "
		"[-f usr_filename]\n");
	printf("-index\tIndex the dictionary.\n");
	printf("-test1\ttest the dictionary search "
		"using the text format dictionary\n");	
	printf("-test2\ttest the dictionary search "
		"using the indexed format "
		"dictionary and user lexicon\n");	
}

void wrong_command(void)
{
	usage();
	err_usr("program quit...\n");
}
