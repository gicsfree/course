export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../jpeg-8c/.libs:
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../freetype-2.4.5/objs/.libs:
sudo chmod 777 /dev/fb0
sudo chmod 777 /dev/input/mice
sudo chmod 777 /dev/input/by-path/platform-i8042-serio-0-event-kbd
