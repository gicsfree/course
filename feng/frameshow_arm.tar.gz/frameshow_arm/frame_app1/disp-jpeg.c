/* disp-jpeg.c */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>

#include "frame.h"

#ifdef FRAME_SUPPORT_JPEG
////////////////////////////////////////////////////////////////
/*
* display jpeg
*/
int display_jpeg(char *filename, fb_info fb_inf)
{
    fb_info jpeg_inf;
    short xres;
    short yres;
    
    u8_t *buf24 = decode_jpeg(filename, &jpeg_inf);
    u8_t *scale_buf = scale24(buf24, fb_inf, jpeg_inf);
# ifdef LCD_RGB565_MODE
    u16_t *buf32 = rgb24to16(scale_buf, fb_inf);
# else
    u32_t *buf32 = rgb24to32(scale_buf, fb_inf);
# endif
    
   printf("w = %d, h = %d, bpp = %d\n", fb_inf.w, fb_inf.h, fb_inf.bpp);

    for(yres = 0; yres < fb_inf.h; ++yres)
    {
        for (xres = 0; xres < fb_inf.w; ++xres)
        {
    		 fb_pixel(fb_inf, xres, yres, buf32[xres + (yres * fb_inf.w)]);
        }
    }
    
    free(buf24);
    free(scale_buf);
    free(buf32);
     
    return 0;
}

/*
* display jpeg with shutter mode
*/
int display_jpeg_shutter(char *filename, fb_info fb_inf)
{
    fb_info jpeg_inf;
    int xres;
    int yres;
    
    u8_t *buf24 = decode_jpeg(filename, &jpeg_inf);
    u8_t *scale_buf = scale24(buf24, fb_inf, jpeg_inf);
# ifdef LCD_RGB565_MODE
    u16_t *buf32 = rgb24to16(scale_buf, fb_inf);
# else
    u32_t *buf32 = rgb24to32(scale_buf, fb_inf);
# endif
    
    for(xres = 0; xres < fb_inf.h ; ++xres)
    {
        if ((xres % 10) < 5)
        {
    		    for (yres = 0; yres < fb_inf.w; ++yres)
    		    {
    			      fb_pixel(fb_inf, yres, xres, buf32[yres + (xres * fb_inf.w)]);
    			  }
    	      usleep(1000);
    	  }
    }
    
    for(xres = 0; xres < fb_inf.h ; ++xres)
    {
        if ((xres % 10) >= 5)
        {
    		    for (yres = 0; yres < fb_inf.w; ++yres)
    		    {
    			      fb_pixel(fb_inf, yres, xres, buf32[yres + (xres * fb_inf.w)]);
    			  }
    		}
    	  usleep(1000);
    }
    
    free(buf24);
    free(scale_buf);
    free(buf32);
    
    return 0;
}

/*
* display jpeg with circle mode
*/
int display_jpeg_circle(const char *jpegname, fb_info fb_inf)
{
    fb_info jpeg_inf;
    int xres;
    int yres;
    int x_loop;
    int y_loop;
    int r_len;
    
    u8_t *buf24 = decode_jpeg(jpegname, &jpeg_inf);
    u8_t *scale_buf = scale24(buf24, fb_inf, jpeg_inf);
# ifdef LCD_RGB565_MODE
    u32_t *buf32 = rgb24to16(scale_buf, fb_inf);
# else
    u32_t *buf32 = rgb24to32(scale_buf, fb_inf);
# endif
    
    for(r_len = 0; r_len < sqrt(fb_inf.w * fb_inf.w + fb_inf.h * fb_inf.h) / 2 + 1; r_len++)
    {
        for (x_loop = 0; x_loop <= r_len; x_loop++)
        {
            for (y_loop = 0; y_loop <= r_len; y_loop++)
            {
                if (((x_loop * x_loop + y_loop * y_loop) <= r_len * r_len)
                   && ((x_loop * x_loop + y_loop * y_loop) >= (r_len - 1) * (r_len - 1)))
                 { 
                    xres = fb_inf.w / 2 + x_loop;
                    yres = fb_inf.h / 2 + y_loop;
                    if ((xres >= 0) && (xres < fb_inf.w) && (yres >= 0) && (yres < fb_inf.h))
                      {
                        fb_pixel(fb_inf, xres, yres, buf32[xres + yres * fb_inf.w]);
                      }

                    xres = fb_inf.w / 2 + x_loop;
                    yres = fb_inf.h / 2 - y_loop;
                    if ((xres >= 0) && (xres < fb_inf.w) && (yres >= 0) && (yres < fb_inf.h))
                      {
                        fb_pixel(fb_inf, xres, yres, buf32[xres + yres * fb_inf.w]);
                      }

                    xres = fb_inf.w / 2 - x_loop;
                    yres = fb_inf.h / 2 + y_loop;
                    if ((xres >= 0) && (xres < fb_inf.w) && (yres >= 0) && (yres < fb_inf.h))
                      {
                        fb_pixel(fb_inf, xres, yres, buf32[xres + yres * fb_inf.w]);
                      }

                    xres = fb_inf.w / 2 - x_loop;
                    yres = fb_inf.h / 2 - y_loop;
                    if ((xres >= 0) && (xres < fb_inf.w) && (yres >= 0) && (yres < fb_inf.h))
                      {
                        fb_pixel(fb_inf, xres, yres, buf32[xres + yres * fb_inf.w]);
                      }
                }
            }            
        }
       usleep(1);
    }
    
    free(buf24);
    free(scale_buf);
    free(buf32);
    
    return 0;
}

#endif    /* FRAME_SUPPORT_JPEG */
