/* main.c */
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>

#include "frame.h"

#ifdef FRAME_SUPPORT_TIME

#define SECOND_PER_YEAR 365*24*60*60UL

////////////////////////////////////////////////////////////////////////
/*
* show clock
*/
int clock_show(const fb_info fb_inf, int x, int y, int x_len, int y_len, int mode)
{
    struct timeval tm_get;
    struct tm *ltm;
    char tm_buf[sizeof(struct tm)] = {0};
    
    gettimeofday(&tm_get, NULL);
    
    ltm = localtime(&tm_get.tv_sec);
    
    strcpy((char*)tm_buf, (char*)asctime(ltm));
     
    display_font_set(16);
     
    if(mode == 1)
     {
        fb_draw_squarearea(fb_inf, x, (y-16), x_len, y_len, 0xFF0000);
     }
     
    display_string ((char*)tm_buf, x, y, fb_inf, 0x00FFFF00);
     
    return 0;
}

#endif   /* FRAME_SUPPORT_TIME */


