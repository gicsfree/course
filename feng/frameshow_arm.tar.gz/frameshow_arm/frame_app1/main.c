/* main.c */
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <linux/fb.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>

#include "frame.h"

///////////////////////////////////////////////////////////////////////////
static fb_info fb_inf;

#ifdef FRAME_SUPPORT_TIME
//////////////////////////////////////////////////////////////////////////
static pthread_cond_t time_cond; 
static pthread_mutex_t time_mutex; 
static int time_signal_mode = 1;

/*
* time thread
*/
void * pro_thread_time(void *pPara)
{
    while(1)
    {
        if(time_signal_mode == 1)
         {
            pthread_cond_wait(&time_cond, &time_mutex);
            clock_show(fb_inf, 600, 40, 400, 32, 0); 
         }
        else
         {
            clock_show(fb_inf, 600, 40, 400, 32, 1);         
         }
        usleep(500000);
    }
}

#endif    /* FRAME_SUPPORT_TIME */

#ifdef FRAME_SUPPORT_KBD
/*
* keyboard thread
*/
void * pro_thread_kbd(void *pPara)
{
    int kfd = -1;
    unsigned char kcode = -1;
     
    kbd_open("/dev/input/by-path/platform-i8042-serio-0-event-kbd", &kfd);
     
    for(;;)
     {
        if ((kcode = kbd_get_code(kfd)) != 0xFF)
         {
            printf ("keyboard get code[%d]\n", (int)kcode); 
         }
        usleep(100000);
     }
     
    return 0;
}

#endif    /* FRAME_SUPPORT_KBD */

#ifdef FRAME_SUPPORT_MOUSE
/*
* mouse test
*/
int test_mouse(const fb_info fb_inf_m)
{
    int mfd = -1;
    u8_t buf[8];
    mouse_event_t mevent;
    
    int m_x = (fb_inf_m.w / 2);
    int m_y = (fb_inf_m.h / 2);
        
    mouse_open(NULL, &mfd);
        
    fb_draw_cursor(fb_inf_m, m_x, m_y);
     
    for(;;)
     {
        if (read(mfd, buf, 8) != -1)
         {
	     mouse_parse(buf,&mevent);
	     //printf("dx:%d\tdy:%d\n", mevent.x, mevent.y);
	     //printf("mx:%d\tmy:%d\n", m_x, m_y);

            if((m_y > 8) && ((m_y < (768 - 8))))
              {
	         fb_restore_cursor(fb_inf_m, m_x, m_y);
              }        
	     m_x += mevent.x;
	     m_y += mevent.y;
              
            if((m_y > 8) && ((m_y < (768 - 8))))
              {
	         fb_draw_cursor(fb_inf_m, m_x, m_y);
                fb_save_cursor(fb_inf_m, m_x, m_y);
              }

	     switch (mevent.button)
              {
	         case 1:
		      printf("left\n");
		    break;

		  case 2:
		      printf("right\n");
		    break;
                     
		  case 4:
		      printf("middle\n");
		    break;

		  default:
		     break;
	     }
	 }	
        usleep(500);
     }
     
    return 0;
}

#endif    /* FRAME_SUPPORT_MOUSE */

/* main */
int main(int argc, char *argv[]) 
{
    pthread_t p_mon_time;
    pthread_t p_mon_kbd;
      
    if (init_fb(&fb_inf) < 0)
    {
    	  fprintf(stderr, "Error initial framebuffer\b")	;
    	  return -1;
    }
    
   printf("fb: w = %d, h = %d, bpp = %d\n", fb_inf.w, fb_inf.h, fb_inf.bpp);

  #ifdef FRAME_SUPPORT_FONT
    if (init_ft("mao.ttf", 64) < 0)
    {
    	  fprintf(stderr, "Error initial font\b")	;
    	  return -1;
    }
  #endif
    
  #ifdef FRAME_SUPPORT_MOUSE
    pthread_create(&p_mon_time, NULL, pro_thread_time, NULL);
  #endif
     
  #ifdef FRAME_SUPPORT_KBD
    pthread_create(&p_mon_kbd, NULL, pro_thread_kbd, NULL);
  #endif
     
  #ifdef FRAME_SUPPORT_JPEG
    display_jpeg("test0.jpg", fb_inf);
    //pthread_cond_signal(&time_cond); 
    sleep(1);
     
    display_jpeg_shutter("test1.jpg", fb_inf);
    //pthread_cond_signal(&time_cond); 
    sleep(1);

    //display_jpeg_circle("test0.jpg", fb_inf);
    //pthread_cond_signal(&time_cond); 
    sleep(1);
  #endif
     
# ifdef LCD_RGB565_MODE
    /* draw a squarearea */
    fb_draw_squarearea(fb_inf, 0, 0, fb_inf.w, fb_inf.h, 0xFF0000);
    
    /* draw five triangle */    
    fb_draw_triangle(fb_inf, 100, 220, 150, 0x00FFFF00);
    
    fb_draw_triangle(fb_inf, 280, 70, 40, 0x00FFFF00);	
    fb_draw_triangle(fb_inf, 340, 170, 40, 0x00FFFF00);
    fb_draw_triangle(fb_inf, 330, 270, 40, 0x00FFFF00);
    fb_draw_triangle(fb_inf, 280, 370, 40, 0x00FFFF00);
#endif
  
  #ifdef FRAME_SUPPORT_FONT
     
    display_font_set(64);
     
    display_string ("北京", 10, 200, fb_inf, 0x00FFFF00);

    display_font_set(32);

    display_string ("中关村", 100, 300, fb_inf, 0x00FF00FF);
     
  #endif
    
  #ifdef FRAME_SUPPORT_MOUSE
    time_signal_mode = 0;
    pthread_cond_signal(&time_cond); 
  #endif
     
  #ifdef FRAME_SUPPORT_MOUSE
    test_mouse(fb_inf);
  #endif
    
    munmap(fb_inf.fbmem, fb_inf.w * fb_inf.h * fb_inf.bpp / 8);
    
    return 0;
}

