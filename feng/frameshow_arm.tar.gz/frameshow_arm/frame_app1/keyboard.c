/* keyborad.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>

#include "frame.h"

#ifdef FRAME_SUPPORT_KBD

/////////////////////////////////////////////////////////////////////
/*
*  open mouse
*/
int kbd_open(char *device_name, int *fd)
{
    if (NULL == device_name)
    {
        device_name = "/dev/input/event2";
    }
    
    if ((*fd = open (device_name, O_RDONLY)) == -1)
     {
        fprintf(stderr, "Open %s:%s\n", device_name, strerror(errno));
        return -1;
     }
    
    return 0;
}

////////////////////////////////////////////////////////////////////////////
/*
* keyboard get code
*/
unsigned char kbd_get_code(int fd)
{
    struct input_event ev[64];
    int size = sizeof (struct input_event);
     
    if (read (fd, ev, (size * 64)) < size)
     {
        fprintf(stderr, " key_get_code() %s!!!\n",strerror(errno));
        return (unsigned char)(0xFF);
     }
     
    if ((ev[0].value != ' ') && (ev[1].value == 1) && (ev[1].type == 1))
     {
          //printf ("keyboard get code[%d]\n", (ev[1].code));
           
          return (unsigned char)(ev[1].code);
     }
    return (unsigned char)(0xFF);
}

#endif /* FRAME_SUPPORT_KBD */

