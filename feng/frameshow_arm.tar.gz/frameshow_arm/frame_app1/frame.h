/* frame.h */
#ifndef _FRAME_H_
#define _FRAME_H_

#define FRAME_SUPPORT_JPEG
#define FRAME_SUPPORT_FONT
//#define FRAME_SUPPORT_MOUSE
//#define FRAME_SUPPORT_TIME
//#define FRAME_SUPPORT_KBD

////////////////////////////////////////////////////////////////////////////
typedef unsigned char  u8_t;
typedef unsigned short u16_t;
typedef unsigned int   u32_t;

typedef struct 
{
    int w;				     /* width */
	  int h;				     /* high */
	  int bpp;				   /* bits per pixel */
	  u8_t *fbmem;
}fb_info;

////////////////////////////////////////////////////////////////////////////
/* initial framebuffer */
extern int init_fb(fb_info *fb_inf);

/* drawing pixel */
extern int fb_pixel(fb_info fb_inf, int x, int y, u32_t color);

/* painting horizontal */
extern int fb_pixel_row(fb_info fb_inf, int x, int y, int len, u32_t color);

/* draw a color ball */
extern int fb_draw_ball(const fb_info fb_inf, int x, int y, int len, u32_t color);

/* draw a color squarearea */
extern int fb_draw_squarearea(const fb_info fb_inf, int x, int y, int x_len, int y_len, u32_t color);

/* draw a triangle */
extern int fb_draw_triangle(const fb_info fb_inf, int x, int y, int len, u32_t color);

#ifdef FRAME_SUPPORT_FONT
////////////////////////////////////////////////////////////////////////////
/* init font library */
extern int init_ft (const char *file, int size);

/* set font size */
extern int display_font_set(unsigned int size);
/* display string */
extern int display_string (const char * buf, int x, int y, fb_info fb_inf, u32_t color);

#endif    /* FRAME_SUPPORT_FONT */

#ifdef FRAME_SUPPORT_MOUSE
////////////////////////////////////////////////////////////////////////////
typedef struct 
{
	int x;
	int y;
	int button;
}mouse_event_t;

////////////////////////////////////////////////////////////////////////////
/* open mouse */
extern int mouse_open(char *device_name, int *fd);
/* parse mouse */
extern int mouse_parse(const u8_t *buf, mouse_event_t* mevent);

/* restore cursor */
extern int fb_restore_cursor(fb_info fb_inf, int x, int y);
/* save cursor */
extern int fb_save_cursor (fb_info fb_inf,int x,int y);
/* draw cursor */
extern int fb_draw_cursor(fb_info fb_inf, int x, int y);

#endif  /* FRAME_SUPPORT_MOUSE */

#ifdef FRAME_SUPPORT_KBD
////////////////////////////////////////////////////////////////////////////
/* open keyboard */
extern int kbd_open(char *device_name, int *fd);

/* keyboard get code */
extern unsigned char kbd_get_code(int fd);

#endif /* FRAME_SUPPORT_KBD */

#ifdef FRAME_SUPPORT_JPEG

#define LCD_RGB565_MODE
////////////////////////////////////////////////////////////////////////////
/* decode jpeg */
extern unsigned char *decode_jpeg (const char *filename, fb_info *jpeg_inf);
# ifdef LCD_RGB565_MODE
/* rgb888 to rgb565 */
extern u16_t * rgb24to16(u8_t *buf24, fb_info jpeg_inf);
# else
/* rgb888 to argb8888 */
extern u32_t * rgb24to32(u8_t *buf24, fb_info jpeg_inf);
# endif /* LCD_RGB565_MODE */
/* scale24 */
u8_t * scale24(u8_t *buf24, fb_info new_inf, fb_info jpeg_inf);

/* display jpeg */
extern int display_jpeg(char *filename, fb_info fb_inf);
/* display jpeg */
extern int display_jpeg_shutter(char *filename, fb_info fb_inf);
extern int display_jpeg_circle(const char *jpegname, fb_info fb_inf);

#endif  /* FRAME_SUPPORT_JPEG */

#ifdef FRAME_SUPPORT_TIME
////////////////////////////////////////////////////////////////////////////
/* show clock */
int clock_show(const fb_info fb_inf, int x, int y, int x_len, int y_len, int mode);

#endif /* FRAME_SUPPORT_TIME */

#endif /* _FRAME_H_ */

