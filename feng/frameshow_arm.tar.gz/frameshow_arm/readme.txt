********************************************************************
                          build process
解压 arm-linux-gcc-4.3.2.tgz 到 /home/akaedu
复制 source-4.3.2 到 /home/akaedu
********************************************************************
@all@
cd 
source source-4.3.2
export CC=arm-linux-gcc

********************************************************************
@build jpegsrc.v8c@
cd frameshow_arm
tar -zxvf jpegsrc.v8c.tar.gz
cd jpeg-8c
chmod -Rf 777 jpegsrc.v8c
./configure --host=arm-linux --prefix=/home/akaedu/frameshow_arm/frame_app/lib/
make
chmod -Rf 777 .libs
make install

********************************************************************
@build freetype-2.4.5@
cd ..
tar -jxvf freetype-2.4.5.tar.bz2
cd freetype-2.4.5
chmod -Rf 777 freetype-2.4.5
./configure --host=arm-linux --prefix=/home/akaedu/frameshow_arm/frame_app/lib/
make
chmod -Rf 777 objs/.libs
make install

************************************************************************
将生成的 jpeg-8c/.libs/libjpeg.so libjpeg.so.8 libjpeg.so.8.3.0(3个） 复制到 /home/akaedu/usr/local/arm/4.3.2/arm-none-linux-gnueabi/libc/armv4t/usr/lib 删除原中的库libjpeg.so libjpeg.so.62 libjpeg.so.62.0.0 (3个） 

***************88************************************************
色彩空间的转换 查看frame_app/frameapp1中jpeg.c 和 frameapp1中dip-jpeg.c 中的用法
键盘和fb的测试 在test_fb test_dev 中

