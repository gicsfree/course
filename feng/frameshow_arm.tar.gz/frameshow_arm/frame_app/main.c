/* main.c */
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "frame.h"

/* main */
int main(int argc, char *argv[]) 
{
    fb_info fb_inf;
    int xloop;
    int yloop;
    
    if (init_fb(&fb_inf) < 0)
    {
    	  fprintf(stderr, "Error initial framebuffer\b")	;
    	  return -1;
    }

    for (yloop = 0; yloop < 480; yloop++)
    {
        for (xloop = 0; xloop < 800; xloop++)
        {
            fb_pixel(fb_inf, xloop, yloop, 0x0000F800);
        }
    }
    sleep(1);

//    display_bmp("1.bmp", fb_inf);
    display_jpeg("1.jpg", fb_inf);

    munmap(fb_inf.fbmem, fb_inf.w * fb_inf.h * fb_inf.bpp / 8);
    
    return 0;
}
